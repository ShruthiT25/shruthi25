#include<iostream>
using namespace std;

//function is to find a triplet
//that sum to a given value.
//returns true if there is a triplet
//with sum equal to 'sum' present in A[].
//Also prints the triplet.

int boolfind3Numbers(int A[],int arr_size,int sum)
{
    int i,j,k;
    //fix the first element as A[i]
    for (int i=0; i<arr_size-2; i++)
{
    //fix the second element as A[j]
    for (int j=i+1; j<arr_size-1; j++)
{
    //fix the third element as A[k]
    for (int k=j+1;k<arr_size; k++)
{
    if(A[i]+A[j]+A[k]==sum)
{
    cout<<"triplet is"<<A[i]<<","<<A[j]<<","<<A[k];
    return true;
     }    
   }    
  }    
 }
 //if there is no triplet exist
 return false;
}

/*Driver code*/
int main()
{
    int A[]={1,4,45,6,10,9};
    int sum=25;
    int arr_size=sizeof(A)/sizeof(A[0]);
  boolfind3Numbers(A,arr_size,sum);
  return 0;
} 
















